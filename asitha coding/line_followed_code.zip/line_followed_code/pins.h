//Motor driver pin allocation
#define right_enable 24
#define right_A 29
#define right_B 28
#define left_enable 26
#define left_A 27
#define left_B 25

#define right_pwm 11
#define left_pwm 10
